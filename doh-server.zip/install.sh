#!/bin/bash
# DoH Proxy Server 安装与配置脚本

set -e

echo "========================================="
echo "   DoH Proxy Server 一键安装脚本"
echo "========================================="

if [ "$EUID" -ne 0 ]; then
  echo "请使用 root 权限运行此脚本 (sudo ./install.sh)"
  exit 1
fi

echo "[1/4] 检查系统与必要软件包..."
apt-get update -y
apt-get install -y curl wget systemd grep

echo "========================================="
echo "   配置优选直连 IP"
echo "========================================="
echo "注意：仅允许输入 IPv4 地址！"
while true; do
    read -p "请输入 Google 优选 IP (必填): " GOOGLE_IP
    if [ -n "$GOOGLE_IP" ]; then
        break
    else
        echo "错误：Google 优选 IP 不能为空，请重新输入！"
    fi
done

echo "[2/4] 安装 Node.js 20.x..."
if ! command -v node &> /dev/null; then
    curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
    apt-get install -y nodejs
else
    echo "Node.js 已安装: $(node -v)"
fi

echo "[3/4] 部署 DoH Proxy 服务代码..."
INSTALL_DIR="/opt/doh-proxy"
mkdir -p "$INSTALL_DIR"

if [ -f "./server.js" ]; then
    cp ./server.js "$INSTALL_DIR/"
    echo "已复制 server.js"
else
    echo "错误: 当前目录下未找到 server.js 文件！"
    exit 1
fi

# 替换 server.js 里的 Google IP
sed -i "s/142.250.5.161/$GOOGLE_IP/g" "$INSTALL_DIR/server.js"

echo "[4/4] 生成随机上报密钥..."
UPLOAD_TOKEN=$(tr -dc 'A-Za-z0-9' </dev/urandom | head -c 16)
sed -i "s/quicgoogle2024/$UPLOAD_TOKEN/g" "$INSTALL_DIR/server.js"
echo "生成的随机密钥为: $UPLOAD_TOKEN"

echo "[5/5] 配置 systemd 服务并启动..."
cat > /etc/systemd/system/doh-proxy.service << 'EOF'
[Unit]
Description=DoH Proxy Server
After=network.target

[Service]
Type=simple
ExecStart=/usr/bin/node /opt/doh-proxy/server.js
Restart=always
RestartSec=3
User=root
WorkingDirectory=/opt/doh-proxy

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable doh-proxy
systemctl restart doh-proxy

echo "[6/6] 创建全局查看命令 quicgoogle..."
cat > /usr/local/bin/quicgoogle << 'EOF'
#!/bin/bash
while true; do
    clear
    echo "=================================================="
    echo "           QUIC Google DoH 控制面板"
    echo "=================================================="
    echo -n "运行状态 : "
    if systemctl is-active --quiet doh-proxy; then
        echo -e "\e[32m🟢 运行中 (Active)\e[0m"
    else
        echo -e "\e[31m🔴 已停止 (Inactive)\e[0m"
    fi

    MAP_FILE="/opt/doh-proxy/googlevideo_map.json"
    if [ -f "$MAP_FILE" ]; then
        NODE_COUNT=$(grep -o '"[0-9]\{1,3\}\.[0-9]\{1,3\}\.[0-9]\{1,3\}\.[0-9]\{1,3\}"' "$MAP_FILE" | wc -l)
        echo "当前映射 : 已加载大约 $NODE_COUNT 个可用 IP 节点"
    else
        echo "当前映射 : 暂无数据 (等待客户端上报)"
    fi

    CURRENT_GOOGLE_IP=$(grep -oP "(?<='google': ')[0-9\.]+" /opt/doh-proxy/server.js | head -1)
    echo "Google优选: $CURRENT_GOOGLE_IP"
    echo "=================================================="
    echo "1. 查看客户端配置信息 (DoH/上报地址/密钥)"
    echo "2. 更换 Google 优选 IP"
    echo "3. 重启 DoH 服务"
    echo "4. 停止 DoH 服务"
    echo "5. 查看实时日志 (按 Ctrl+C 退出日志)"
    echo "0. 退出面板"
    echo "=================================================="
    read -p "请输入选项 [0-5]: " choice
    case $choice in
        1)
            echo ""
            echo "[客户端配置信息]"
            echo "DoH 代理地址 : https://<你的域名>/doh/dns-query"
            echo "节点上报地址 : http://<你的域名>:3053/upload-map (或配反代 https://<你的域名>/upload-map)"
            UPLOAD_TOKEN=$(grep -oP "(?<=UPLOAD_TOKEN = process.env.UPLOAD_TOKEN || ')[^']+" /opt/doh-proxy/server.js)
            echo "上报认证密钥 : $UPLOAD_TOKEN"
            echo ""
            read -p "按回车键继续..."
            ;;
        2)
            echo ""
            echo "注意：仅允许输入 IPv4 地址！"
            read -p "请输入新的 Google 优选 IP: " NEW_IP
            if [ -n "$NEW_IP" ]; then
                sed -i "s/$CURRENT_GOOGLE_IP/$NEW_IP/g" /opt/doh-proxy/server.js
                systemctl restart doh-proxy
                echo "更换成功！DoH 服务已自动重启。"
            else
                echo "输入为空，已取消更换。"
            fi
            echo ""
            read -p "按回车键继续..."
            ;;
        3)
            echo ""
            systemctl restart doh-proxy
            echo "服务已重启！"
            read -p "按回车键继续..."
            ;;
        4)
            echo ""
            systemctl stop doh-proxy
            echo "服务已停止！"
            read -p "按回车键继续..."
            ;;
        5)
            echo ""
            journalctl -u doh-proxy -f
            ;;
        0)
            echo ""
            echo "已退出控制面板。"
            exit 0
            ;;
        *)
            echo "无效选项，请重新输入！"
            sleep 1
            ;;
    esac
done
EOF
chmod +x /usr/local/bin/quicgoogle

echo "========================================="
echo "安装完成！"
echo "DoH Proxy Server 现已在后台运行。"
echo "你现在可以随时在终端输入命令 \`quicgoogle\` 打开交互式控制面板！"
echo "========================================="
