#!/bin/bash
# DoH Proxy Server 安装与配置脚本

set -e

echo "========================================="
echo "   DoH Proxy Server 一键安装脚本"
echo "========================================="

if [ "$EUID" -ne 0 ]; then
  echo "请使用 root 权限运行此脚本 (sudo ./install.sh)"
  exit 1
fi

echo "[1/4] 更新系统并安装必要的软件包..."
apt-get update -y
apt-get install -y curl wget systemd

echo "[2/4] 安装 Node.js 20.x..."
if ! command -v node &> /dev/null; then
    curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
    apt-get install -y nodejs
else
    echo "Node.js 已安装: $(node -v)"
fi

echo "[3/4] 部署 DoH Proxy 服务代码..."
INSTALL_DIR="/opt/doh-proxy"
mkdir -p "$INSTALL_DIR"

if [ -f "./server.js" ]; then
    cp ./server.js "$INSTALL_DIR/"
    echo "已复制 server.js"
else
    echo "错误: 当前目录下未找到 server.js 文件！"
    exit 1
fi


echo "[4/4] 生成随机上报密钥..."
UPLOAD_TOKEN=$(tr -dc 'A-Za-z0-9' </dev/urandom | head -c 16)
sed -i "s/quicgoogle2024/$UPLOAD_TOKEN/g" "$INSTALL_DIR/server.js"
echo "生成的随机密钥为: $UPLOAD_TOKEN"

echo "[5/5] 配置 systemd 服务并启动..."
cat > /etc/systemd/system/doh-proxy.service << 'EOF'
[Unit]
Description=DoH Proxy Server
After=network.target

[Service]
Type=simple
ExecStart=/usr/bin/node /opt/doh-proxy/server.js
Restart=always
RestartSec=3
User=root
WorkingDirectory=/opt/doh-proxy

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable doh-proxy
systemctl restart doh-proxy

echo "[6/6] 创建全局查看命令 quicgoogle..."
cat > /usr/local/bin/quicgoogle << 'EOF'
#!/bin/bash
echo "=================================================="
echo "           QUIC Google DoH 状态面板"
echo "=================================================="
echo -n "运行状态 : "
if systemctl is-active --quiet doh-proxy; then
    echo -e "\e[32m🟢 运行中 (Active)\e[0m"
else
    echo -e "\e[31m🔴 已停止 (Inactive)\e[0m"
fi

MAP_FILE="/opt/doh-proxy/googlevideo_map.json"
if [ -f "$MAP_FILE" ]; then
    NODE_COUNT=$(grep -o '"[0-9]\{1,3\}\.[0-9]\{1,3\}\.[0-9]\{1,3\}\.[0-9]\{1,3\}"' "$MAP_FILE" | wc -l)
    echo "当前映射 : 已加载大约 $NODE_COUNT 个可用 IP 节点"
else
    echo "当前映射 : 暂无数据 (等待客户端上报)"
fi

echo ""
echo "[客户端配置信息]"
echo "DoH 代理地址 : https://<你的域名>/doh/dns-query"
PUBLIC_IP=$(curl -s ifconfig.me || echo "<VPS_IP>")
echo "节点上报地址 : http://$PUBLIC_IP:3053/upload-map"
echo "上报认证密钥 : quicgoogle2024"
echo "=================================================="
EOF
chmod +x /usr/local/bin/quicgoogle

echo "========================================="
echo "安装完成！"
echo "DoH Proxy Server 现已在后台运行。"
echo "你现在可以随时在终端输入命令 \`quicgoogle\` 查看状态和配置信息！"
echo "========================================="
