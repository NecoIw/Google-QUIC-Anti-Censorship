#!/bin/bash
# DoH Proxy Server 安装与配置脚本

set -e

echo "========================================="
echo "   DoH Proxy Server 一键安装脚本"
echo "========================================="

# 检查 root 权限
if [ "$EUID" -ne 0 ]; then
  echo "请使用 root 权限运行此脚本 (sudo ./install.sh)"
  exit 1
fi

echo "[1/4] 更新系统并安装必要的软件包..."
apt-get update -y
apt-get install -y curl wget systemd

echo "[2/4] 安装 Node.js 20.x..."
if ! command -v node &> /dev/null; then
    curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
    apt-get install -y nodejs
else
    echo "Node.js 已安装: $(node -v)"
fi

echo "[3/4] 部署 DoH Proxy 服务代码..."
INSTALL_DIR="/opt/doh-proxy"
mkdir -p "$INSTALL_DIR"

# 复制当前目录下的 server.js 和 googlevideo_map.json 到安装目录
if [ -f "./server.js" ]; then
    cp ./server.js "$INSTALL_DIR/"
    echo "已复制 server.js"
else
    echo "错误: 当前目录下未找到 server.js 文件！请确保你在包含 server.js 的目录中运行此脚本。"
    exit 1
fi

if [ -f "./googlevideo_success.txt" ]; then
    echo "检测到 googlevideo_success.txt，正在生成 JSON 映射表..."
    # 使用 node 将 txt 转换为 json
    node -e "
    const fs = require('fs');
    const lines = fs.readFileSync('./googlevideo_success.txt', 'utf8').split('\n');
    const map = {};
    for (const line of lines) {
      const parts = line.trim().split(' ');
      if (parts.length === 2) {
        const domain = parts[0].toLowerCase();
        const ip = parts[1];
        if (!map[domain]) map[domain] = [];
        if (!map[domain].includes(ip)) map[domain].push(ip);
      }
    }
    fs.writeFileSync('$INSTALL_DIR/googlevideo_map.json', JSON.stringify(map));
    console.log('生成了 ' + Object.keys(map).length + ' 个域名的映射规则。');
    "
    # 修改 server.js 以加载 map.json
    node -e "
    const fs = require('fs');
    let code = fs.readFileSync('$INSTALL_DIR/server.js', 'utf8');
    const insertCode = \`
const fs = require('fs');
const path = require('path');

// 加载 googlevideo 直连 IP 映射表
let GOOGLEVIDEO_MAP = {};
try {
  const mapPath = path.join(__dirname, 'googlevideo_map.json');
  if (fs.existsSync(mapPath)) {
    GOOGLEVIDEO_MAP = JSON.parse(fs.readFileSync(mapPath, 'utf-8'));
    console.log('[googlevideo_map] 已加载 ' + Object.keys(GOOGLEVIDEO_MAP).length + ' 个域名映射');
  }
} catch (err) {
  console.log('[googlevideo_map] 加载失败: ' + err.message);
}
\`;
    
    // Insert after const http = require('http');
    code = code.replace(/const http = require\('http'\);/, 'const http = require(\\'http\\');\\n' + insertCode);
    
    // Modify fetchIp logic
    const oldFetch = /if \\(rule\\.fetchIp\\) \\{\\s+ipv4s = await resolveViaDoH\\(queryName, 1\\);\\s+\\}/;
    const newFetch = \`if (rule.fetchIp) {
    const mapKey = queryName.toLowerCase();
    if (GOOGLEVIDEO_MAP[mapKey] && GOOGLEVIDEO_MAP[mapKey].length > 0) {
      ipv4s = GOOGLEVIDEO_MAP[mapKey];
      log('[googlevideo_map] 命中本地映射: ' + mapKey + ' -> ' + ipv4s.join(', '));
    } else {
      ipv4s = await resolveViaDoH(queryName, 1);
    }
  }\`;
    code = code.replace(oldFetch, newFetch);
    fs.writeFileSync('$INSTALL_DIR/server.js', code);
    "
else
    echo "未检测到 googlevideo_success.txt，跳过本地直连 IP 映射配置 (默认使用远程 DNS 解析)。"
fi

echo "[4/4] 配置 systemd 服务并启动..."
cat > /etc/systemd/system/doh-proxy.service << 'EOF'
[Unit]
Description=DoH Proxy Server
After=network.target

[Service]
Type=simple
ExecStart=/usr/bin/node /opt/doh-proxy/server.js
Restart=always
RestartSec=3
User=root
WorkingDirectory=/opt/doh-proxy

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable doh-proxy
systemctl restart doh-proxy

echo "========================================="
echo "安装完成！"
echo "DoH Proxy Server 现已在后台运行并设置为开机自启。"
echo ""
echo "默认监听端口: 127.0.0.1:3053"
echo "查看运行状态: systemctl status doh-proxy"
echo "查看实时日志: journalctl -u doh-proxy -f"
echo ""
echo "建议配置 Nginx 或 Caddy 将 HTTPS 请求反向代理到 3053 端口"
echo "========================================="
