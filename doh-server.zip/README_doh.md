# Custom DoH Proxy Server

这是一个基于 Node.js 的轻量级 DNS-over-HTTPS (DoH) 代理服务器。它的主要作用是：

1. **强制 HTTPS 记录注入**：拦截针对特定域名（如 Google、YouTube）的 DNS 请求，主动返回 `alpn=h3`，强制浏览器首次连接即走 QUIC 协议。
2. **直连 IP 映射**：配合 `googlevideo_scanner.py` 扫描出的可用节点，直接返回未被阻断的直连 IP，避免 GFW 封锁。
3. **ECH 支持**：可以为 Cloudflare 等支持 ECH 的 CDN 提供静态的 ECH 公钥记录（绕过 SNI 封锁）。

## 部署教程

本程序需要部署在**海外 VPS** 上（不受 GFW DNS 污染影响）。

### 1. 上传文件
将本压缩包内的所有文件，以及你本地扫描出来的 `googlevideo_success.txt`（如果有的话），一起上传到你的 VPS 的同一个目录中。

例如：
- `server.js`
- `install.sh`
- `googlevideo_success.txt` (可选，用于 YouTube 直连)

### 2. 执行安装脚本
在 VPS 上，以 root 身份运行安装脚本：

```bash
chmod +x install.sh
sudo ./install.sh
```

**安装脚本会自动做以下事情：**
- 安装 Node.js 20.x
- 如果检测到 `googlevideo_success.txt`，会自动帮你将其转换成 `googlevideo_map.json` 并配置好加载规则。
- 自动配置 systemd 守护进程并设置为开机自启。
- 服务启动后，将会在本地 `127.0.0.1:3053` 监听。

### 3. 配置反向代理与 HTTPS
由于 DoH 必须使用 HTTPS，你需要使用 Caddy 或 Nginx 为其配置域名和 SSL 证书，并将 `/doh/dns-query` 的请求转发给 `3053` 端口。

#### 示例：Caddy 配置 (Caddyfile)
如果你使用 Caddy，配置非常简单：

```caddyfile
your-doh-domain.com {
    handle /doh/* {
        reverse_proxy localhost:3053
    }
}
```

#### 示例：Nginx 配置
如果你使用 Nginx：

```nginx
server {
    listen 443 ssl http2;
    server_name your-doh-domain.com;

    ssl_certificate /path/to/cert.pem;
    ssl_certificate_key /path/to/key.pem;

    location /doh/ {
        proxy_pass http://127.0.0.1:3053;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    }
}
```

### 4. 客户端使用
配置好服务端后，在浏览器（Chrome/Firefox）或路由器的安全 DNS 设置中，填入你的专属 DoH 地址：
`https://your-doh-domain.com/doh/dns-query`

## 自定义修改
如果你想自定义 Cloudflare 的优选 IP 或其他逻辑，请直接编辑 `server.js` 文件顶部对应的配置区域，然后重启服务：
```bash
sudo systemctl restart doh-proxy
```
