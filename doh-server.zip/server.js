// NodeJS DoH Proxy (Adapted from Cloudflare Worker)
const http = require('http');


const PORT = 3053;
const SNIPPETS_MODE = false;
const ALLOWED_PATH  = '/doh/dns-query';
const OPTIMIZED_TTL = 1;

const DEBUG = true;
const ECS_IP = '1.2.4.8';  // EDNS Client Subnet IP，改为你 VPS 附近的公共 DNS IP

// Malaysia IPs
const ipListV4 = {
  'cf': '162.159.140.229',  // Cloudflare 优选 IP，请替换为你自己的,
  'google': '142.250.5.161',  // Google 优选 IP，请替换为你自己的,
  'gcdn': '142.250.5.161',  // Google CDN 优选 IP,
};
const ipListV6 = {};

const ECH_TYPES = {
  'cf': {
    sourceDomain:    'cloudflare-ech.com',
    mode:            'local',
    localData:       'AEX+DQBBFAAgACApLi37Py03Z3TinersGhjjAEUIL3f9fMaU+5eDjSoHAAAEAAEAAQASY2xvdWRmbGFyZS1lY2guY29tAAA=',
    soaKeyword:      'cloudflare.com',
    staticDomains:   ['workers.dev', 'pages.dev', 'cloudflarestatus.com'],
    defaultIpListV4: 'cf',
    defaultIpListV6: null,
  },
  'google': {
    sourceDomain:    'www.google.com',
    mode:            'fetch',
    localData:       '',
    soaKeyword:      'google.com',
    staticDomains:   ['google.com', 'google.com.hk', 'google.com.tw', 'google.com.sg',
                      'google.co.jp', 'google.co.kr', 'google.co.uk', 'google.co.in',
                      'youtube.com', 'ytimg.com',
                      'ggpht.com', 'googleapis.com', 'gstatic.com',
                      'googleusercontent.com', 'youtu.be', 'youtube-nocookie.com',
                      'gvt1.com', 'gvt2.com', 'gvt3.com'],
    defaultIpListV4: 'google',
    defaultIpListV6: null,
  },
};

const DOMAIN_RULES = [
  { domain: '#twimg.com',    ipListV4: 'cf', echType: null},
  { domain: '#twitter.com',  ipListV4: 'cf', echType: null},
  { domain: '#x.com',        ipListV4: 'cf', echType: null},
  { domain: 'upload.x.com',  ipListV4: 'cf', echType: null},
  { domain: 'api.x.com',     ipListV4: 'cf', echType: null},
  { domain: 'grok.x.com',    ipListV4: 'cf', echType: null},

  { domain: '#google.com',           ipListV4: 'google', echType: 'google'},
  { domain: '#google.com.hk',       ipListV4: 'google', echType: 'google'},
  { domain: '#google.com.tw',       ipListV4: 'google', echType: 'google'},
  { domain: '#google.com.sg',       ipListV4: 'google', echType: 'google'},
  { domain: '#google.co.jp',        ipListV4: 'google', echType: 'google'},
  { domain: '#google.co.kr',        ipListV4: 'google', echType: 'google'},
  { domain: '#google.co.uk',        ipListV4: 'google', echType: 'google'},
  { domain: '#google.co.in',        ipListV4: 'google', echType: 'google'},
  
  { domain: '#googleapis.com',       ipListV4: 'gcdn', echType: 'google'},
  { domain: '#gstatic.com',          ipListV4: 'gcdn', echType: 'google'},
  { domain: '#googleusercontent.com',ipListV4: 'google', echType: 'google'},
  { domain: '#ggpht.com',            ipListV4: 'gcdn', echType: 'google'},
  { domain: 'i.ytimg.com', ipListV4: 'google', echType: null },
  { domain: 'i1.ytimg.com', ipListV4: 'google', echType: null },
  { domain: '#ytimg.com', ipListV4: 'google', echType: null },
  
  { domain: '#gvt1.com',             ipListV4: 'google', echType: 'google'},
  { domain: '#gvt2.com',             ipListV4: 'google', echType: 'google'},
  { domain: '#gvt3.com',             ipListV4: 'google', echType: 'google'},

  { domain: '#youtube.com',          ipListV4: 'google', echType: 'google'},
  { domain: '#googlevideo.com', fetchIp: true, echType: null },
  { domain: '#withgoogle.com', ipListV4: 'google', echType: null },
  { domain: '#youtu.be',             ipListV4: 'google', echType: 'google'},
  { domain: '#youtube-nocookie.com', ipListV4: 'google', echType: 'google'},
];

const UPSTREAM_DNS_SERVERS = [
  'https://dns.google/dns-query',
];

const CACHE = {
  MEM_CF:          true,
  MEM_CF_TTL:      1_800_000,
  MEM_CF_MAX:      500,
  MEM_ECH:         true,
  MEM_IP:          true,
  MEM_IP_TTL:      300_000,
  PERSIST_CF:      true,
  PERSIST_CF_TTL:  3600,
  PERSIST_ECH:     true,
  PERSIST_ECH_TTL: 86400,
};

const DNSSEC_BLOCKED = new Set([43, 46, 47, 48, 50]);

const _PERSIST_CF  = CACHE.PERSIST_CF  && !SNIPPETS_MODE;
const _PERSIST_ECH = CACHE.PERSIST_ECH && !SNIPPETS_MODE;
const _ALPN_PROTOS = ['h3', 'h2'];

const memCfCache   = new Map();                
const memEchCaches = Object.create(null);      
const memIpCache   = new Map();               

const TTL_BYTES = [
  (OPTIMIZED_TTL >> 24) & 0xFF,
  (OPTIMIZED_TTL >> 16) & 0xFF,
  (OPTIMIZED_TTL >> 8)  & 0xFF,
   OPTIMIZED_TTL        & 0xFF,
];
const ALPN_H3 = encodeAlpn(_ALPN_PROTOS);

function log(...args) {
  if (DEBUG) console.log('[DoH Node]', ...args);
}

// 鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲
// Entry - Node.js HTTP Server Adapter
// 鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲
const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
    
    if (url.pathname === '/doh/health') {
      res.writeHead(200);
      return res.end('ok');
    }
    
    const init = {
      method: req.method,
      headers: req.headers,
    };
    if (req.method === 'POST') {
      const chunks = [];
      for await (const chunk of req) chunks.push(chunk);
      init.body = Buffer.concat(chunks);
    }
    const webReq = new Request(url.href, init);
    const webRes = await handleRequest(webReq, {});
    
    res.writeHead(webRes.status, Object.fromEntries(webRes.headers));
    const body = Buffer.from(await webRes.arrayBuffer());
    res.end(body);
  } catch (e) {
    console.error('Crash:', e);
    res.writeHead(500);
    res.end(e.stack);
  }
});
server.listen(PORT, '127.0.0.1', () => {
  console.log('DoH proxy listening on 127.0.0.1:' + PORT);
});

// 鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲
// Core logic from Worker
// 鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲鈺愨晲

async function handleRequest(request, env) {
  const url = new URL(request.url);

  if (url.pathname !== ALLOWED_PATH)
    return new Response('Not Found', { status: 404 });
  if (request.method !== 'GET' && request.method !== 'POST')
    return new Response('Method Not Allowed', { status: 405 });

  try {
    let dnsQuery = await extractDnsQuery(request);
    if (!dnsQuery) return new Response('Bad Request', { status: 400 });

    dnsQuery = stripDnssecFromQuery(dnsQuery);

    const { queryName, queryType } = parseDnsQuery(dnsQuery);
    log(`query name=${queryName} type=${queryType}`);

    if (DNSSEC_BLOCKED.has(queryType)) {
      log(`blocked DNSSEC type=${queryType} for ${queryName}`);
      return createEmptyDnsResponse(dnsQuery);
    }

    const rule = matchDomainRule(queryName);
    if (rule) {
      if (rule.passthrough) {
        log(`passthrough: ${queryName}`);
        return filterDnssecFromResponse(await forwardToUpstream(dnsQuery));
      }
      if (rule.ipv4Only) {
        log(`ipv4Only: ${queryName}`);
        return handleIPv4Only(queryType, dnsQuery);
      }
      log(`domain rule matched: ${queryName}`);
      return handleRuleQuery(queryType, dnsQuery, rule, env, queryName);
    }

    if (SNIPPETS_MODE) {
      const echType = await detectDomainEchType(queryName, env);
      log(`ECH type for ${queryName}: ${echType}`);
      if (echType) {
        return handleRuleQuery(queryType, dnsQuery, createSyntheticRule(echType), env, queryName);
      }
      return filterDnssecFromResponse(await forwardToUpstream(dnsQuery));
    } else {
      const abort           = new AbortController();
      const upstreamPromise = forwardToUpstream(dnsQuery, abort.signal);
      const echType         = await detectDomainEchType(queryName, env);
      log(`ECH type for ${queryName}: ${echType}`);
      if (echType) {
        abort.abort();
        return handleRuleQuery(queryType, dnsQuery, createSyntheticRule(echType), env, queryName);
      }
      return filterDnssecFromResponse(await upstreamPromise);
    }

  } catch (err) {
    log(`handleRequest error: ${err?.message}`);
    return new Response('Internal Server Error', { status: 500 });
  }
}

async function handleRuleQuery(queryType, originalQuery, rule, env, queryName) {
  let ipv4s = [];
  let ipv6s = [];
  if (rule.fetchIp) {
    ipv4s = await resolveViaDoH(queryName, 1);
  } else {
    const res = await Promise.all([
      resolveIpList(rule.ipListV4 ?? null, 4),
      resolveIpList(rule.ipListV6 ?? null, 6),
    ]);
    ipv4s = res[0];
    ipv6s = res[1];
  }

  if (queryType === 1) {   // A
        return ipv4s.length
      ? createARecordResponse(originalQuery, ipv4s)
      : createEmptyDnsResponse(originalQuery);
  }
  if (queryType === 28) {  // AAAA
        return ipv6s.length
      ? createAAAAResponse(originalQuery, ipv6s)
      : createEmptyDnsResponse(originalQuery);
  }
  if (queryType === 5)     // CNAME
    return createEmptyDnsResponse(originalQuery);

  if (queryType === 65) {  // HTTPS (SVCB)
    const ech = rule.echType ? await getEchConfig(rule.echType, env) : null;
    return createHttpsResponse(originalQuery, ipv4s, ipv6s, ech);
  }

  return filterDnssecFromResponse(
    await forwardToUpstream(originalQuery)
  );
}

async function handleIPv4Only(queryType, originalQuery) {
  if (queryType === 28) {
    return createEmptyDnsResponse(originalQuery);
  }
  return filterDnssecFromResponse(await forwardToUpstream(originalQuery));
}

function matchDomainRule(queryName) {
  const name = queryName.toLowerCase();
  for (const rule of DOMAIN_RULES) {
    const pat = rule.domain.toLowerCase();
    if (pat.startsWith('#')) {
      const base = pat.slice(1);
      if (name === base || name.endsWith('.' + base)) return rule;
    } else if (pat.startsWith('^*.')) {
      const suffix = pat.slice(3);
      if (name.endsWith('.' + suffix)) return rule;
    } else if (pat.startsWith('*.')) {
      const suffix = pat.slice(2);
      if (name.endsWith('.' + suffix)) {
        const sub = name.slice(0, name.length - suffix.length - 1);
        if (!sub.includes('.')) return rule;
      }
    } else {
      if (name === pat) return rule;
    }
  }
  return null;
}

async function resolveIpList(listName, version) {
  if (!listName) return [];
  const cacheKey = `v${version}:${listName}`;
  const now = Date.now();
  if (CACHE.MEM_IP) {
    const hit = memIpCache.get(cacheKey);
    if (hit && now - hit.ts < CACHE.MEM_IP_TTL) return hit.ips;
  }
  const rawList = version === 4 ? (ipListV4[listName] ?? '') : (ipListV6[listName] ?? '');
  const items   = rawList.split(',').map(s => s.trim()).filter(Boolean);
  const ips     = [];
  for (const item of items) {
    const isDomain = version === 4 ? /[a-zA-Z]/.test(item) : !item.includes(':');
    if (isDomain) {
      const resolved = await resolveViaDoH(item, version === 4 ? 1 : 28);
      ips.push(...resolved);
    } else {
      ips.push(item);
    }
  }
  if (CACHE.MEM_IP) memIpCache.set(cacheKey, { ips, ts: now });
  return ips;
}

async function resolveViaDoH(domain, rrType) {
  const url = `https://dns.google/resolve?name=${encodeURIComponent(domain)}&type=${rrType}`;
  try {
    const r = await fetch(url, { headers: { accept: 'application/dns-json' } });
    if (!r.ok) return [];
    const data = await r.json();
    return (data.Answer ?? []).filter(rr => rr.type === rrType).map(rr => rr.data);
  } catch { return []; }
}

function createSyntheticRule(echTypeName) {
  const cfg = ECH_TYPES[echTypeName];
  return {
    ipListV4: cfg?.defaultIpListV4 ?? null,
    ipListV6: cfg?.defaultIpListV6 ?? null,
    echType:  echTypeName,
  };
}

async function detectDomainEchType(domain, env) {
  const key = domain.toLowerCase();
  const now = Date.now();
  if (CACHE.MEM_CF) {
    const hit = memCfCache.get(key);
    if (hit && now - hit.ts < CACHE.MEM_CF_TTL) return hit.echType;
  }
  for (const [typeName, cfg] of Object.entries(ECH_TYPES)) {
    if (cfg.staticDomains?.some(d => domain === d || domain.endsWith('.' + d))) {
      writeEchTypeCache(key, typeName, now, env);
      return typeName;
    }
  }
  if (_PERSIST_CF) {
    const cached = await persistGet('echtype:' + key);
    if (cached !== null) {
      const echType = cached || null;
      if (CACHE.MEM_CF) memCfCache.set(key, { echType, ts: now });
      return echType;
    }
  }
  let detectedType = null;
  try {
    const soaData = await querySoaData(domain);
    for (const [typeName, cfg] of Object.entries(ECH_TYPES)) {
      if (cfg.soaKeyword && soaData.includes(cfg.soaKeyword.toLowerCase())) {
        detectedType = typeName;
        break;
      }
    }
  } catch {}
  writeEchTypeCache(key, detectedType, now, env);
  return detectedType;
}

function writeEchTypeCache(key, echType, now, env) {
  if (CACHE.MEM_CF) {
    memCfCache.set(key, { echType, ts: now });
    if (memCfCache.size > CACHE.MEM_CF_MAX && Math.random() < 0.05) {
      const cutoff = now - CACHE.MEM_CF_TTL;
      for (const [k, v] of memCfCache) if (v.ts < cutoff) memCfCache.delete(k);
    }
  }
  if (_PERSIST_CF)
    persistSet('echtype:' + key, echType ?? '', CACHE.PERSIST_CF_TTL).catch(() => {});
}

async function querySoaData(domain) {
  if (SNIPPETS_MODE)
    return querySoaDataSingle(domain, 'https://dns.google/resolve');
  const results = await Promise.allSettled([
    querySoaDataSingle(domain, 'https://dns.google/resolve'),
  ]);
  for (const r of results) if (r.status === 'fulfilled' && r.value) return r.value;
  return '';
}

async function querySoaDataSingle(domain, baseUrl) {
  const url = `${baseUrl}?name=${encodeURIComponent(domain)}&type=SOA`;
  const r = await fetch(url, { headers: { accept: 'application/dns-json' } });
  if (!r.ok) throw new Error(`HTTP ${r.status}`);
  const data = await r.json();
  for (const section of [data.Answer, data.Authority]) {
    if (!Array.isArray(section)) continue;
    for (const rr of section) {
      if (rr.type === 6) return rr.data.toLowerCase();
    }
  }
  return '';
}

async function getEchConfig(typeName, env) {
  const cfg = ECH_TYPES[typeName];
  if (!cfg) return null;
  if (cfg.mode === 'local') {
    if (!memEchCaches[typeName]) memEchCaches[typeName] = base64UrlDecode(cfg.localData);
    return memEchCaches[typeName];
  }
  if (CACHE.MEM_ECH && memEchCaches[typeName]) return memEchCaches[typeName];
  if (_PERSIST_ECH) {
    const cached = await persistGet(`ech:${typeName}`);
    if (cached) {
      const ech = base64UrlDecode(cached);
      if (CACHE.MEM_ECH) memEchCaches[typeName] = ech;
      return ech;
    }
  }
  try {
    const q    = stripDnssecFromQuery(buildDnsQuery(cfg.sourceDomain, 65));
    const resp = await forwardToUpstream(q);
    const ech  = extractEchFromHttpsResponse(new Uint8Array(await resp.arrayBuffer()));
    if (ech?.length) {
      if (CACHE.MEM_ECH) memEchCaches[typeName] = ech;
      if (_PERSIST_ECH) persistSet(`ech:${typeName}`, base64UrlEncode(ech), CACHE.PERSIST_ECH_TTL).catch(() => {});
      return ech;
    }
  } catch {}
  const fallback = base64UrlDecode(cfg.localData);
  if (CACHE.MEM_ECH) memEchCaches[typeName] = fallback;
  return fallback;
}

function extractEchFromHttpsResponse(data) {
  let off = 12;
  const qdCount = (data[4] << 8) | data[5];
  for (let i = 0; i < qdCount && off < data.length; i++) { off = skipName(data, off); off += 4; }
  const anCount = (data[6] << 8) | data[7];
  for (let i = 0; i < anCount && off < data.length; i++) {
    off = skipName(data, off);
    const type = (data[off] << 8) | data[off + 1];
    off += 8;
    const rdl = (data[off] << 8) | data[off + 1]; off += 2;
    const end  = off + rdl;
    if (type === 65) {
      off += 3;
      while (off < end - 4) {
        const key = (data[off] << 8) | data[off + 1];
        const len = (data[off + 2] << 8) | data[off + 3]; off += 4;
        if (key === 5) return data.slice(off, off + len);
        off += len;
      }
    }
    off = end;
  }
  return null;
}

function appendEcsToQuery(query) {
  if (!ECS_IP) return query;
  const octets    = ECS_IP.split('.').map(Number);
  const prefixLen = 24;
  const addrBytes = octets.slice(0, Math.ceil(prefixLen / 8));
  const optionLen = 4 + addrBytes.length;
  const ecsOption = [
    0x00, 0x08,
    (optionLen >> 8) & 0xFF, optionLen & 0xFF,
    0x00, 0x01,
    prefixLen,
    0x00,
    ...addrBytes,
  ];
  const opt = [
    0x00,
    0x00, 0x29,
    0x10, 0x00,
    0x00, 0x00, 0x00, 0x00,
    (ecsOption.length >> 8) & 0xFF, ecsOption.length & 0xFF,
    ...ecsOption,
  ];
  const arCount = (query[10] << 8) | query[11];
  const result  = new Uint8Array(query.length + opt.length);
  result.set(query);
  result.set(opt, query.length);
  result[10] = ((arCount + 1) >> 8) & 0xFF;
  result[11] =  (arCount + 1)       & 0xFF;
  return result;
}

const PERSIST_NS = 'https://doh-internal.cache/';
async function persistGet(key) {
  if (SNIPPETS_MODE) return null;
  try {
    // Return null since we don't have CF caches API in Node
    return null;
  } catch { return null; }
}

async function persistSet(key, value, ttlSec) {
  if (SNIPPETS_MODE) return;
  try {
    // No-op in Node
  } catch {}
}

async function forwardToUpstream(dnsQuery, signal) {
  const queryWithEcs = appendEcsToQuery(dnsQuery);
  const b64          = base64UrlEncode(queryWithEcs);
  const fetch_opts   = { headers: { accept: 'application/dns-message' }, signal };

  if (SNIPPETS_MODE) {
    try {
      const r = await fetch(`${UPSTREAM_DNS_SERVERS[0]}?dns=${b64}`, fetch_opts);
      if (!r.ok) throw new Error(`HTTP ${r.status}`);
      return new Response(r.body, { headers: { 'content-type': 'application/dns-message' } });
    } catch (e) {
      if (signal?.aborted) return new Response('Aborted', { status: 499 });
      throw e;
    }
  }

  const races = UPSTREAM_DNS_SERVERS.map(s =>
    fetch(`${s}?dns=${b64}`, fetch_opts).then(r =>
      r.ok ? r : Promise.reject(new Error(String(r.status)))
    )
  );
  try {
    const r = await Promise.any(races);
    return new Response(r.body, { headers: { 'content-type': 'application/dns-message' } });
  } catch (e) {
    if (signal?.aborted) return new Response('Aborted', { status: 499 });
    throw e;
  }
}

function createHttpsResponse(originalQuery, ipv4s, ipv6s, ech) {
  const data = [0x00, 0x01, 0x00];
  data.push(0x00, 0x01, (ALPN_H3.length >> 8) & 0xFF, ALPN_H3.length & 0xFF, ...ALPN_H3);
  if (ipv4s.length) {
    const bytes = ipv4s.flatMap(ip => ip.split('.').map(Number));
    data.push(0x00, 0x04, (bytes.length >> 8) & 0xFF, bytes.length & 0xFF, ...bytes);
  }
  if (ech?.length)
    data.push(0x00, 0x05, (ech.length >> 8) & 0xFF, ech.length & 0xFF, ...ech);
  if (ipv6s.length) {
    const bytes = ipv6s.flatMap(ip => Array.from(parseIPv6(ip)));
    data.push(0x00, 0x06, (bytes.length >> 8) & 0xFF, bytes.length & 0xFF, ...bytes);
  }
  return buildRRResponse(originalQuery, 65, new Uint8Array(data));
}

function createARecordResponse(originalQuery, ips) {
  const hdr = new Uint8Array(originalQuery);
  hdr[2] = 0x81; hdr[3] = 0x80; hdr[6] = 0x00; hdr[7] = ips.length;
  const ans = new Uint8Array(ips.length * 16);
  let pos = 0;
  for (const ip of ips) {
    ans[pos++] = 0xC0; ans[pos++] = 0x0C;
    ans[pos++] = 0x00; ans[pos++] = 0x01;
    ans[pos++] = 0x00; ans[pos++] = 0x01;
    ans[pos++] = TTL_BYTES[0]; ans[pos++] = TTL_BYTES[1];
    ans[pos++] = TTL_BYTES[2]; ans[pos++] = TTL_BYTES[3];
    ans[pos++] = 0x00; ans[pos++] = 0x04;
    for (const octet of ip.split('.')) ans[pos++] = Number(octet);
  }
  const out = new Uint8Array(hdr.length + ans.length);
  out.set(hdr); out.set(ans, hdr.length);
  return new Response(out, { headers: { 'content-type': 'application/dns-message' } });
}

function createAAAAResponse(originalQuery, ips) {
  const hdr = new Uint8Array(originalQuery);
  hdr[2] = 0x81; hdr[3] = 0x80; hdr[6] = 0x00; hdr[7] = ips.length;
  const chunks = [];
  for (const ip of ips) {
    chunks.push(
      0xC0, 0x0C, 0x00, 0x1C, 0x00, 0x01,
      TTL_BYTES[0], TTL_BYTES[1], TTL_BYTES[2], TTL_BYTES[3],
      0x00, 0x10, ...parseIPv6(ip)
    );
  }
  const ans = new Uint8Array(chunks);
  const out = new Uint8Array(hdr.length + ans.length);
  out.set(hdr); out.set(ans, hdr.length);
  return new Response(out, { headers: { 'content-type': 'application/dns-message' } });
}

function createEmptyDnsResponse(originalQuery) {
  const r = new Uint8Array(originalQuery);
  r[2] = 0x81; r[3] = 0x80; r[6] = 0x00; r[7] = 0x00;
  return new Response(r, { headers: { 'content-type': 'application/dns-message' } });
}

function buildRRResponse(originalQuery, rrType, rdata) {
  const hdr = new Uint8Array(originalQuery);
  hdr[2] = 0x81; hdr[3] = 0x80; hdr[6] = 0x00; hdr[7] = 0x01;
  const ans = new Uint8Array(12 + rdata.length);
  ans[0] = 0xC0; ans[1] = 0x0C;
  ans[2] = (rrType >> 8) & 0xFF; ans[3] = rrType & 0xFF;
  ans[4] = 0x00; ans[5] = 0x01;
  ans[6] = TTL_BYTES[0]; ans[7] = TTL_BYTES[1];
  ans[8] = TTL_BYTES[2]; ans[9] = TTL_BYTES[3];
  ans[10] = (rdata.length >> 8) & 0xFF; ans[11] = rdata.length & 0xFF;
  ans.set(rdata, 12);
  const out = new Uint8Array(hdr.length + ans.length);
  out.set(hdr); out.set(ans, hdr.length);
  return new Response(out, { headers: { 'content-type': 'application/dns-message' } });
}

function parseIPv6(ip) {
  const bytes   = new Uint8Array(16);
  const halves  = ip.split('::');
  if (halves.length === 2) {
    const left  = halves[0] ? halves[0].split(':') : [];
    const right = halves[1] ? halves[1].split(':') : [];
    let p = 0;
    for (const g of left)  { const v = parseInt(g, 16); bytes[p++] = (v >> 8) & 0xFF; bytes[p++] = v & 0xFF; }
    p = 16 - right.length * 2;
    for (const g of right) { const v = parseInt(g, 16); bytes[p++] = (v >> 8) & 0xFF; bytes[p++] = v & 0xFF; }
  } else {
    let p = 0;
    for (const g of ip.split(':')) { const v = parseInt(g, 16); bytes[p++] = (v >> 8) & 0xFF; bytes[p++] = v & 0xFF; }
  }
  return bytes;
}

function encodeAlpn(list) {
  const out = [];
  for (const s of list) out.push(s.length, ...s.split('').map(c => c.charCodeAt(0)));
  return new Uint8Array(out);
}

function skipName(data, off) {
  while (off < data.length) {
    const len = data[off];
    if ((len & 0xC0) === 0xC0) return off + 2;
    if (len === 0) return off + 1;
    off += len + 1;
  }
  return off;
}

function stripDnssecFromQuery(dnsQuery) {
  const q = new Uint8Array(dnsQuery);
  q[2] = q[2] & 0xDF;
  if (((q[10] << 8) | q[11]) === 0) return q;
  let off = 12;
  const qdCount = (q[4] << 8) | q[5];
  for (let i = 0; i < qdCount && off < q.length; i++) { off = skipName(q, off); off += 4; }
  off = skipRRSection(q, off, (q[6] << 8) | q[7]);
  off = skipRRSection(q, off, (q[8] << 8) | q[9]);
  const arCount = (q[10] << 8) | q[11];
  for (let i = 0; i < arCount && off < q.length; i++) {
    const rrStart = off;
    off = skipName(q, off);
    const type = (q[off] << 8) | q[off + 1];
    off += 8;
    const rdl = (q[off] << 8) | q[off + 1]; off += 2 + rdl;
    if (type === 41) {
      const out = q.slice(0, rrStart);
      out[10] = 0; out[11] = 0;
      return out;
    }
  }
  return q;
}

function skipRRSection(buf, off, count) {
  for (let i = 0; i < count && off < buf.length; i++) {
    off = skipName(buf, off);
    off += 8;
    const rdl = (buf[off] << 8) | buf[off + 1]; off += 2 + rdl;
  }
  return off;
}

async function filterDnssecFromResponse(response) {
  const data = new Uint8Array(await response.arrayBuffer());
  data[2] = data[2] & 0xDF;
  return new Response(filterDnssecRecords(data), {
    headers: { 'content-type': 'application/dns-message' },
  });
}

function filterDnssecRecords(resp) {
  let off = 12;
  const qdCount = (resp[4] << 8) | resp[5];
  for (let i = 0; i < qdCount && off < resp.length; i++) { off = skipName(resp, off); off += 4; }
  const sectStart = off;
  const anCount = (resp[6]  << 8) | resp[7];
  const nsCount = (resp[8]  << 8) | resp[9];
  const arCount = (resp[10] << 8) | resp[11];
  let needsFilter = false;
  let scan = sectStart;
  for (let i = 0; i < anCount + nsCount + arCount && scan < resp.length; i++) {
    scan = skipName(resp, scan);
    if (scan + 10 > resp.length) break;
    const type = (resp[scan] << 8) | resp[scan + 1];
    if (DNSSEC_BLOCKED.has(type)) { needsFilter = true; break; }
    scan += 8;
    const rdl = (resp[scan] << 8) | resp[scan + 1]; scan += 2 + rdl;
  }
  if (!needsFilter) return resp;
  const [anRecs, newAn, off2] = filterSection(resp, sectStart, anCount);
  const [nsRecs, newNs, off3] = filterSection(resp, off2,      nsCount);
  const [arRecs, newAr]       = filterSection(resp, off3,      arCount);
  const header = resp.slice(0, sectStart);
  const all    = [...anRecs, ...nsRecs, ...arRecs];
  const out    = new Uint8Array(header.length + all.reduce((s, r) => s + r.length, 0));
  let pos = 0;
  out.set(header, pos); pos += header.length;
  for (const r of all) { out.set(r, pos); pos += r.length; }
  out[6]  = (newAn >> 8) & 0xFF; out[7]  = newAn & 0xFF;
  out[8]  = (newNs >> 8) & 0xFF; out[9]  = newNs & 0xFF;
  out[10] = (newAr >> 8) & 0xFF; out[11] = newAr & 0xFF;
  return out;
}

function filterSection(buf, off, count) {
  const recs = []; let kept = 0;
  for (let i = 0; i < count && off < buf.length; i++) {
    const start = off;
    off = skipName(buf, off);
    if (off + 10 > buf.length) break;
    const type = (buf[off] << 8) | buf[off + 1];
    off += 8;
    const rdl = (buf[off] << 8) | buf[off + 1]; off += 2 + rdl;
    if (!DNSSEC_BLOCKED.has(type)) { recs.push(buf.slice(start, off)); kept++; }
  }
  return [recs, kept, off];
}

async function extractDnsQuery(request) {
  if (request.method === 'GET') {
    const url = new URL(request.url);
    const p = url.searchParams.get('dns');
    return p ? base64UrlDecode(p) : null;
  }
  if (request.headers.get('content-type')?.includes('application/dns-message'))
    return new Uint8Array(await request.arrayBuffer());
  return null;
}

function parseDnsQuery(q) {
  let off = 12, name = '';
  while (off < q.length && q[off]) {
    const len = q[off];
    if (name) name += '.';
    name += String.fromCharCode(...q.slice(off + 1, off + 1 + len));
    off += len + 1;
  }
  off++;
  return {
    queryName: name.toLowerCase(),
    queryType: off + 1 < q.length ? (q[off] << 8) | q[off + 1] : 0,
  };
}

function buildDnsQuery(domain, type) {
  const q = [0x00, 0x00, 0x01, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00];
  for (const label of domain.split('.'))
    q.push(label.length, ...label.split('').map(c => c.charCodeAt(0)));
  q.push(0x00, 0x00, type, 0x00, 0x01);
  return new Uint8Array(q);
}

function base64UrlDecode(str) {
  str = str.replace(/-/g, '+').replace(/_/g, '/');
  str += '='.repeat((4 - str.length % 4) % 4);
  const bin = atob(str);
  return new Uint8Array(bin.length).map((_, i) => bin.charCodeAt(i));
}

function base64UrlEncode(bytes) {
  return btoa(String.fromCharCode(...bytes))
    .replace(/\+/g, '-').replace(/\//g, '_').replace(/=/g, '');
}
