import os
import json
import urllib.request
import urllib.error

SUCCESS_FILE = "googlevideo_success.txt"

def main():
    print("========================================")
    print("   QUIC Google Nodes 自动上报工具")
    print("========================================")
    
    if not os.path.exists(SUCCESS_FILE):
        print(f"错误: 找不到 {SUCCESS_FILE}！请先运行 scanner 扫出结果。")
        input("按回车键退出...")
        return

    # Parse success file
    print(f"正在读取 {SUCCESS_FILE}...")
    map_data = {}
    count = 0
    with open(SUCCESS_FILE, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            parts = line.split()
            if len(parts) == 2:
                domain, ip = parts[0].lower(), parts[1]
                if domain not in map_data:
                    map_data[domain] = []
                if ip not in map_data[domain]:
                    map_data[domain].append(ip)
                count += 1
                
    print(f"✅ 读取完毕！共发现 {count} 个可用节点映射。")
    print("-" * 40)
    
    api_url = input("请输入服务端上报 API 地址 (例如 http://1.2.3.4:3053/upload-map): ").strip()
    if not api_url:
        print("已取消上报。")
        input("按回车键退出...")
        return
        
    token = input("请输入上报认证密钥 (Token) [默认 quicgoogle2024]: ").strip()
    if not token:
        token = "quicgoogle2024"
        
    print(f"\n正在将数据上传至: {api_url} ...")
    
    json_data = json.dumps(map_data).encode("utf-8")
    req = urllib.request.Request(api_url, data=json_data, method='POST')
    req.add_header('Content-Type', 'application/json')
    req.add_header('x-token', token)
    
    try:
        with urllib.request.urlopen(req, timeout=15) as response:
            res_body = response.read().decode('utf-8')
            print("\n🎉 上报成功！服务端已实时更新。")
            print(f"服务端返回: {res_body}")
    except urllib.error.HTTPError as e:
        print(f"\n❌ 上报失败！HTTP 错误: {e.code} {e.reason}")
        print("请检查 Token 是否正确。")
    except Exception as e:
        print(f"\n❌ 上报失败！网络错误: {e}")
        print("请检查服务端 IP 或端口是否被防火墙拦截。")
        
    input("\n按回车键退出...")

if __name__ == "__main__":
    main()
