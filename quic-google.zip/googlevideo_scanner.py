"""
GoogleVideo QUIC Node Scanner
扫描 googlevideo.com 的全部子域名，通过 DoH 解析 IP 并 Ping 测试直连可用性。
筛选出可直连的 QUIC 视频节点 IP。
"""
import urllib.request
import urllib.error
import socket
import struct
import base64
import time
import sys
import os
import subprocess
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from collections import defaultdict

# ╔══════════════════════════════════════════════════════════════╗
# ║                     用户配置区                               ║
# ╚══════════════════════════════════════════════════════════════╝

# DoH 服务器地址（DNS-over-HTTPS，使用 RFC 8484 wire format）
# 默认使用 Google Public DNS，你也可以替换为自己的 DoH 服务器

# 动态获取 DoH URL，避免硬编码
DOH_URL = input("请输入 DoH 服务地址 (默认: https://dns.google/dns-query): ").strip()
if not DOH_URL:
    DOH_URL = "https://dns.google/dns-query"


# 输出文件名
RESOLVED_FILE = "googlevideo_resolved.txt"    # 第一轮 DNS 解析出的全部 域名+IP
SUCCESS_FILE  = "googlevideo_success.txt"     # Ping 通的（直连可用节点）
FAIL_FILE     = "googlevideo_fail.txt"        # Ping 不通的（后续轮次重试）

# 并发数
DNS_WORKERS  = 20   # DNS 解析并发线程数
PING_WORKERS = 50   # Ping 测试并发线程数

# ╔══════════════════════════════════════════════════════════════╗
# ║                     核心代码                                 ║
# ╚══════════════════════════════════════════════════════════════╝

print_lock = threading.Lock()

def safe_print(msg):
    with print_lock:
        sys.stdout.write(msg + "\n")
        sys.stdout.flush()

def build_dns_query(domain):
    """构建 DNS A 记录查询报文（wire format）"""
    query = struct.pack(">HHHHHH", 0xAAAA, 0x0100, 1, 0, 0, 0)
    for part in domain.split('.'):
        query += struct.pack("B", len(part)) + part.encode('utf-8')
    query += b'\x00'
    query += struct.pack(">HH", 1, 1)  # Type A, Class IN
    return query

def parse_dns_response(response):
    """解析 DNS 响应报文，提取 A 记录 IP"""
    ips = []
    try:
        qdcount, ancount = struct.unpack(">HH", response[4:8])
        off = 12
        for _ in range(qdcount):
            while response[off] != 0:
                if response[off] >= 0xC0:
                    off += 2
                    break
                off += response[off] + 1
            if response[off] == 0:
                off += 1
            off += 4
        for _ in range(ancount):
            if off >= len(response): break
            if response[off] >= 0xC0:
                off += 2
            else:
                while response[off] != 0:
                    off += response[off] + 1
                off += 1
            if off + 10 > len(response): break
            rtype, _, _, rdlen = struct.unpack(">HHIH", response[off:off+10])
            off += 10
            if rtype == 1 and rdlen == 4:
                ips.append(socket.inet_ntoa(response[off:off+4]))
            off += rdlen
    except Exception:
        pass
    return ips

def resolve_doh(domain):
    """通过 DoH（RFC 8484 wire format）解析域名的 A 记录"""
    query = build_dns_query(domain)
    b64 = base64.urlsafe_b64encode(query).decode('utf-8').rstrip('=')
    url = f"{DOH_URL}?dns={b64}"
    req = urllib.request.Request(url, headers={'accept': 'application/dns-message'})
    try:
        with urllib.request.urlopen(req, timeout=5) as r:
            return parse_dns_response(r.read()), None
    except urllib.error.HTTPError as e:
        return [], f"HTTP {e.code}"
    except Exception as e:
        return [], str(e)

def ping_ip(ip):
    """使用系统原生 ICMP Ping 测试 IP 直连可用性（绕过代理）"""
    try:
        res = subprocess.run(
            ["ping", "-n", "1", "-w", "1000", ip],
            capture_output=True, text=True,
            creationflags=subprocess.CREATE_NO_WINDOW
        )
        return "TTL=" in res.stdout or "ttl=" in res.stdout
    except:
        return False

def load_lines(path):
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return [line.strip() for line in f if line.strip()]
    except FileNotFoundError:
        return []

def save_lines(path, lines):
    with open(path, 'w', encoding='utf-8') as f:
        for line in lines:
            f.write(line + "\n")

def append_lines(path, lines):
    with open(path, 'a', encoding='utf-8') as f:
        for line in lines:
            f.write(line + "\n")

def get_subdomains():
    """从 crt.name 证书透明度日志获取 googlevideo.com 全部子域名"""
    safe_print("正在从 crt.name 获取 googlevideo.com 全部子域名...")
    try:
        req = urllib.request.Request("https://crt.name/v1/search?apex=googlevideo.com")
        with urllib.request.urlopen(req, timeout=15) as r:
            text = r.read().decode('utf-8')
            domains = [line.strip() for line in text.split('\n') if line.strip()]
            safe_print(f"成功获取到 {len(domains)} 个子域名。")
            return domains
    except Exception as e:
        safe_print(f"获取子域名失败: {e}")
        return []

def extract_domains_from_fail(fail_lines):
    """从 fail.txt 的 'domain ip' 行中提取去重的域名列表"""
    domains = set()
    for line in fail_lines:
        parts = line.rsplit(' ', 1)
        if len(parts) == 2:
            domains.add(parts[0])
    return list(domains)

def resolve_and_ping(domains, round_num, is_first_round=False):
    """
    对给定的域名列表：
    1. 向 DoH 解析 IP
    2. Ping 测试
    返回 (success_records, fail_records)
    """
    safe_print(f"\n[阶段 1/2] 向 DoH 解析 {len(domains)} 个域名的 IP...")

    ip_to_domains = defaultdict(list)
    resolved_count = 0
    dead_count = 0
    error_count = 0
    all_resolved_records = []

    with ThreadPoolExecutor(max_workers=DNS_WORKERS) as executor:
        futures = {executor.submit(resolve_doh, d): d for d in domains}
        for future in as_completed(futures):
            domain = futures[future]
            resolved_count += 1
            prefix = f"[{resolved_count}/{len(domains)}]"
            try:
                ips, err = future.result()
                if err:
                    error_count += 1
                    safe_print(f"{prefix} [DoH报错] {domain} - {err}")
                elif not ips:
                    dead_count += 1
                    if dead_count % 200 == 0:
                        safe_print(f"{prefix} [废弃域名] 已跳过 {dead_count} 个无记录域名...")
                else:
                    for ip in ips:
                        ip_to_domains[ip].append(domain)
                        all_resolved_records.append(f"{domain} {ip}")
                    safe_print(f"{prefix} [解析成功] {domain} -> {', '.join(ips)}")
            except Exception:
                pass

    # 第一轮时保存全部解析结果
    if is_first_round and all_resolved_records:
        save_lines(RESOLVED_FILE, all_resolved_records)
        safe_print(f">>> 全部解析记录已保存到 {RESOLVED_FILE}")

    unique_ips = list(ip_to_domains.keys())
    safe_print(f"\n>>> 解析完成！有效 IP: {len(unique_ips)} 个 | 废弃: {dead_count} | 报错: {error_count}")

    if not unique_ips:
        return [], []

    # ── Ping 测试 ──
    safe_print(f"\n[阶段 2/2] 开始 Ping 测试 {len(unique_ips)} 个 IP...")

    success_records = []
    fail_records = []
    pinged_count = 0

    with ThreadPoolExecutor(max_workers=PING_WORKERS) as executor:
        futures_ping = {executor.submit(ping_ip, ip): ip for ip in unique_ips}
        for future in as_completed(futures_ping):
            ip = futures_ping[future]
            pinged_count += 1
            prefix = f"[{pinged_count}/{len(unique_ips)}]"
            try:
                alive = future.result()
                matched = ip_to_domains[ip]
                if alive:
                    for d in matched:
                        success_records.append(f"{d} {ip}")
                    safe_print(f"{prefix} [直连成功] {ip} (带飞 {len(matched)} 个域名)")
                else:
                    for d in matched:
                        fail_records.append(f"{d} {ip}")
                    safe_print(f"{prefix} [超时] {ip}")
            except Exception:
                pass

    return success_records, fail_records

def main():
    try:
        # ── 检测存档：是否有上次未完成的 fail.txt ──
        existing_fail = load_lines(FAIL_FILE)
        existing_success = load_lines(SUCCESS_FILE)

        if existing_fail:
            safe_print(f"检测到存档！上次进度:")
            safe_print(f"  成功: {len(existing_success)} 条 ({SUCCESS_FILE})")
            safe_print(f"  待重试: {len(existing_fail)} 条 ({FAIL_FILE})")
            safe_print(f"从存档继续，跳过第一轮 DNS 全量解析。\n")
            round_num = 2
        else:
            # ══════════════════════════════════════════════════════════
            #  第一轮：全量 DNS 解析 + Ping
            # ══════════════════════════════════════════════════════════
            safe_print(f"\n{'='*60}")
            safe_print(f"  第 1 轮：DNS 全量解析 + Ping 测试")
            safe_print(f"{'='*60}")

            domains = get_subdomains()
            if not domains:
                return

            success_records, fail_records = resolve_and_ping(domains, 1, is_first_round=True)

            # 立即保存文件！
            save_lines(SUCCESS_FILE, success_records)
            save_lines(FAIL_FILE, fail_records)

            safe_print(f"\n{'='*60}")
            safe_print(f"  第 1 轮结束 - 文件已保存！")
            safe_print(f"  直连成功: {len(success_records)} 条 → {SUCCESS_FILE}")
            safe_print(f"  Ping失败: {len(fail_records)} 条 → {FAIL_FILE}")
            safe_print(f"{'='*60}")

            if not fail_records:
                safe_print("所有 IP 全部直连成功！任务完成！")
                return

            round_num = 2

        # ══════════════════════════════════════════════════════════
        #  后续轮次：从 fail.txt 提取域名，重新查 DNS，再 Ping
        # ══════════════════════════════════════════════════════════
        while True:
            safe_print(f"\n等待 3 秒后开始第 {round_num} 轮重试...")
            time.sleep(3)

            fail_lines = load_lines(FAIL_FILE)
            if not fail_lines:
                safe_print(f"\nfail.txt 已清空！所有节点全部确认完毕，任务完成！")
                break

            # 从 fail.txt 中提取域名（去重），重新查 DNS
            retry_domains = extract_domains_from_fail(fail_lines)

            safe_print(f"\n{'='*60}")
            safe_print(f"  第 {round_num} 轮：对 {len(retry_domains)} 个失败域名重新查询 DNS + Ping")
            safe_print(f"{'='*60}")

            new_success, still_fail = resolve_and_ping(retry_domains, round_num)

            # 成功的增量追加到 success.txt
            if new_success:
                append_lines(SUCCESS_FILE, new_success)

            # 失败的覆盖写回 fail.txt
            save_lines(FAIL_FILE, still_fail)

            total_success = len(load_lines(SUCCESS_FILE))

            safe_print(f"\n{'='*60}")
            safe_print(f"  第 {round_num} 轮结束 - 文件已保存！")
            safe_print(f"  本轮翻身成功: {len(new_success)} 条")
            safe_print(f"  仍然失败: {len(still_fail)} 条")
            safe_print(f"  累计成功总数: {total_success} 条")
            safe_print(f"{'='*60}")

            if not still_fail:
                safe_print("\nfail.txt 已清空！所有节点全部确认完毕，任务完成！")
                break

            round_num += 1

    except KeyboardInterrupt:
        safe_print("\n[!] 用户取消！已完成轮次的结果全部已保存在:")
        safe_print(f"    成功: {SUCCESS_FILE}")
        safe_print(f"    待重试: {FAIL_FILE}")
        safe_print(f"    全部解析: {RESOLVED_FILE}")
        os._exit(0)

if __name__ == "__main__":
    main()
